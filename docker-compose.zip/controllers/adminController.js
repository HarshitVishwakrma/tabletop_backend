const pool = require("../config/db");

// ---------------------------
// BRANCH MANAGEMENT
// ---------------------------

// Get all branches for the logged-in partner
const getBranches = async (req, res, next) => {
  try {
    const { account_id } = req.partner;
    const result = await pool.query(
      `SELECT 
        b.id, 
        b.name, 
        b.address, 
        b.phone,
        b.is_active,
        (SELECT COUNT(*) FROM tables t WHERE t.branch_id = b.id)::int as tables_count,
        (SELECT COUNT(*) FROM orders o WHERE o.branch_id = b.id AND o.status NOT IN ('served', 'cancelled'))::int as active_orders
       FROM branches b 
       WHERE b.account_id = $1 
       ORDER BY b.id ASC`,
      [account_id]
    );
    res.json(result.rows);
  } catch (error) {
    next(error);
  }
};

// Create a new branch
const createBranch = async (req, res, next) => {
  try {
    const { account_id, user_id } = req.partner;
    const { name, address, phone } = req.body;

    if (!name) {
      return res.status(400).json({ error: "Branch name is required" });
    }

    const result = await pool.query(
      "INSERT INTO branches (account_id, name, address, phone) VALUES ($1, $2, $3, $4) RETURNING *",
      [account_id, name, address || null, phone || null]
    );

    const newBranch = result.rows[0];

    // Grant user access in user_branches
    if (user_id) {
      await pool.query(
        "INSERT INTO user_branches (user_id, branch_id) VALUES ($1, $2) ON CONFLICT DO NOTHING",
        [user_id, newBranch.id]
      );
    }

    res.status(201).json({
      message: "Branch created successfully",
      branch: newBranch
    });
  } catch (error) {
    next(error);
  }
};

// ---------------------------
// TABLE MANAGEMENT
// ---------------------------

// Get all tables for a specific branch
const getTables = async (req, res, next) => {
  try {
    const { branch_id, account_id } = req.staff; // provided by authStaff based on x-branch-id
    const result = await pool.query(
      `SELECT id, account_id, branch_id, table_number, qr_token, qr_token as qr_code_hash, is_active 
       FROM tables 
       WHERE branch_id = $1 AND account_id = $2 
       ORDER BY id ASC`,
      [branch_id, account_id]
    );
    res.json(result.rows);
  } catch (error) {
    next(error);
  }
};

// Create a new table and generate its unique QR code hash/token
const createTable = async (req, res, next) => {
  try {
    const { branch_id, account_id } = req.staff;
    const { table_number } = req.body;

    if (!table_number) {
      return res.status(400).json({ error: "Table number is required" });
    }

    const result = await pool.query(
      `INSERT INTO tables (account_id, branch_id, table_number) 
       VALUES ($1, $2, $3) 
       RETURNING id, account_id, branch_id, table_number, qr_token, qr_token as qr_code_hash, is_active`,
      [account_id, branch_id, table_number]
    );

    res.status(201).json({
      message: "Table created successfully",
      table: result.rows[0]
    });
  } catch (error) {
    next(error);
  }
};


const settleSession = async (req, res, next) => {
  const client = await pool.connect();
  try {
    const { account_id, branch_id, user_id } = req.staff;
    const { id } = req.params;
    await client.query("BEGIN");

    const { rows: [s] } = await client.query(
      "SELECT * FROM table_sessions WHERE id = $1 FOR UPDATE", [id]);   // row lock
    if (!s || s.account_id !== account_id || s.branch_id !== branch_id)
      return fail(404, "Session not found");
    if (s.status === "closed") return fail(409, "Already closed");
    if (s.status !== "payment_pending") return fail(409, "Bill hasn't been requested yet");

    // Recompute from the items, never trust the stored bill alone
    const totals = await computeTotals(client, id);          // same helper generateBill uses
    const { rows: [bill] } = await client.query(
      "SELECT * FROM bills WHERE session_id = $1 FOR UPDATE", [id]);
    if (Math.abs(totals.total - Number(bill.total)) > 0.01)
      return fail(409, "Bill changed since it was shown. Refresh and try again.");

    // Warn staff if food is still in the kitchen (they can confirm with force: true)
    const { rows: [{ n }] } = await client.query(
      "SELECT COUNT(*)::int n FROM orders WHERE session_id=$1 AND status IN ('pending','accepted','preparing')", [id]);
    if (n > 0 && !req.body.force) return fail(409, "Some orders are still being prepared");

    // Sequential, gap-free bill number per branch per financial year
    const fy = financialYear(new Date());                    // '2026-27' (April–March)
    await client.query("SELECT pg_advisory_xact_lock($1)", [branch_id]);
    const { rows: [{ next }] } = await client.query(
      "SELECT COALESCE(MAX(bill_number),0)+1 AS next FROM bills WHERE branch_id=$1 AND financial_year=$2",
      [branch_id, fy]);

    await client.query(
      `UPDATE bills SET payment_status='paid', financial_year=$2, bill_number=$3,
              finalized_at=NOW(), settled_by=$4 WHERE id=$1`, [bill.id, fy, next, user_id]);
    await client.query(
      "INSERT INTO payments (account_id, bill_id, method, amount, status) VALUES ($1,$2,'cash',$3,'success')",
      [account_id, bill.id, bill.total]);
    await client.query(
      `UPDATE table_sessions SET status='closed', ended_at=NOW(), ended_by='staff',
              closed_reason='paid', closed_by_user_id=$2 WHERE id=$1`, [id, user_id]);
    await client.query("COMMIT");
    // emit table_session_closed to the branch room, then res.json(...)
  } catch (e) { await client.query("ROLLBACK"); next(e); } finally { client.release(); }
};

module.exports = {
  getBranches,
  createBranch,
  getTables,
  createTable, 
  settleSession
};
